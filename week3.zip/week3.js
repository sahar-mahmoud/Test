let  movies={ title:"Clueless",long:"2 hours",dayshow:'sunday'};
console.log(movies);
console.log(movies.long);

let askage=prompt("enter your age:");
let age=18;

if(askage>=age){
    console.log(`welcom to cinima`);
    console.log(`please reserve your seat`);
}
else{
    console.log(`Ask your parents`);
}
 







